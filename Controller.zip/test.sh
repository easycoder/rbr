#!/bin/bash
echo `date +"%Y-%M-%d %T"`" - Hello RBR" >> /home/pi/log.txt
