#!/bin/python3

from easycoder import Program

Program('/home/graham/dev/rbr/roombyroom/Controller/ui/rbrconf.ecs').start()
