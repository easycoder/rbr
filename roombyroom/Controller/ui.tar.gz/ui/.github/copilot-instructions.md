## Quick orientation for AI coding agents

This file gives focused, actionable guidance to be productive in the RBR Controller UI codebase.
Keep entries short and concrete — reference the files below when making changes.

### Big picture
- The Controller UI is a Python/Qt application that renders and controls the local UI for the Room-By-Room product. See `README.md` for high-level context.
- There are two important runtime domains:
  - ECS scripts (.ecs) interpreted by the EasyCoder `Program` engine. These scripts drive UI behaviour and are compiled/handled by Handler implementations (eg. `rbr_ui.py`).
  - The Qt GUI components implemented in `widgets.py` (RBRWindow, Room, Menu, ModeDialog, Profiles, Banner, etc.).

### Key files (start here)
- `rbrconf.py` — program entrypoint for the controller (calls Program(...).start()). Example: `Program('/home/graham/dev/rbr/roombyroom/Controller/ui/rbrconf.ecs').start()`
- `rbr_ui.py` — the EasyCoder Handler for UI-language keywords. Look for paired methods named `k_<keyword>` (compile/parse) and `r_<keyword>` (runtime action).
- `widgets.py` — Qt widgets and UI primitives. Changing visual behaviour usually belongs here.
- `rbrdebug.py` — separate debug UI (script viewer + simple debugger). Useful to run locally while editing ECS scripts.
- `keyboard.py` — virtual keyboard + `TextReceiver` used by ECS-created keyboards.
- `img/` — image assets referenced by widgets; do not rename images without updating usages.

### Conventions and patterns to preserve
- EasyCoder Handler pattern: every keyword has two methods when required: `k_<name>` (parsing/compilation) and `r_<name>` (runtime). If you add a keyword, implement both as needed.
- UI objects are stored in symbol/variable records used by the ECS runtime. `r_<...>` handlers typically call `self.getVariable(...)` and manipulate `.widget` / `.window` / `.value` fields.
- Naming: GUI element classes are in `widgets.py` (e.g. `RBRWindow`, `Room`, `Menu`, `ModeDialog`). Reuse existing classes; add new small components there.
- Style: widget look & feel is supplied via inline `setStyleSheet()` calls and helper functions (eg. `defaultQLabelStyle`). Keep new style additions consistent with these helpers.
- Frameless windows: `RBRWindow` uses empty title to create frameless windows — preserve this behaviour when toggling window titles.

### Typical developer workflows (how to run & debug)
- Run the controller UI (uses local Qt display):
  - cd to `Controller/ui` and run: `python3 rbrconf.py` (this runs the ECS program referenced in the file)
- Run the debug UI (script viewer): `python3 rbrdebug.py` — helpful for inspecting ECS scripts without running the full Program.
- If running on a headless CI or remote machine, Qt programs require an X server (use Xvfb or run tests that don't instantiate QApplication).

### Integration points & external dependencies
- PySide6 is required for GUI (`widgets.py`, `rbrdebug.py`, `keyboard.py`).
- `easycoder` is a runtime dependency: the `Program` and `Handler` classes drive ECS script execution. Changes to ECS handlers must respect the `easycoder` interface.
- Remote web UI and PHP server are out-of-repo; this controller writes/reads data that remote services consume. Don't change external API shapes without cross-checking server code.

### EasyCoder core (new)
- The interpreter core lives in the `easycoder/` directory. Key files you will likely read or call:
  - `ec_handler.py` — Handler base class and the runtime callback conventions (`k_<name>` / `r_<name>`).
  - `ec_program.py` — `Program` bootstrap, runtime properties (screenWidth/screenHeight, `rbrwin`, `roomIndex`, `run()` entrypoints).
  - `ec_compiler.py` / `ec_classes.py` / `ec_condition.py` — parsing and compilation helpers used by handlers.
  - `ec_core.py` / `ec_value.py` — runtime helpers and value representations.
  - `ec_keyboard.py` / `ec_pyside.py` — integrations used by the UI layer.

  Practical rules when editing handlers:
  - Preserve the Handler contract: implement both `k_<keyword>` (compiler/parser hook) and `r_<keyword>` (runtime action) when the keyword affects runtime state or parsing.
  - Use provided methods like `getVariable()`, `getSymbolRecord()`, `putSymbolValue()` and `getRuntimeValue()` instead of reaching into Program internals.
  - Avoid changing method signatures on Handler subclasses — the engine expects the naming and signatures in the current core.

### Quick runnable examples
- Run the full UI (uses the local EasyCoder engine):

  ```bash
  cd Controller/ui
  python3 rbrconf.py
  ```

- Run a single ECS script directly via the Program class (quick smoke test):

  ```bash
  python3 -c "from easycoder import Program; Program('path/to/file.ecs').start()"
  ```

### Caution
- If you change APIs in `easycoder/` update all Handler implementations and run the UI to validate behavior. Don't change the `k_`/`r_` naming or the core `Program` properties without coordinating across the repo.

### Practical hints & examples (code pointers)
- To see how parsing+runtime combine, inspect `rbr_ui.py`:
  - `k_create` / `r_create` implement `create rbrwin` and `create room` behaviour.
  - `k_set` / `r_set` handle `set attribute ...` and `set <widget> as other view ...`.
- Widgets expectations:
  - `RBRWindow.initContent()` creates Banner, Profiles and room layouts; `getElement(name)` provides named elements (e.g. `'banner'`, `'profiles'`).
  - `Room` exposes `.modeButton`, `.toolsButton`, and `.setTemperature()` for runtime handlers to call.
- Keyboard: `Keyboard` and `VirtualKeyboard` (in `keyboard.py`) expect a `TextReceiver` (wraps QLineEdit-like fields). Use `TextReceiver.add_character()` and `.backspace()`.
- Config file for the debug UI: `~/.rbrdebug.conf` is used by `rbrdebug.py` to persist geometry.

### Safe edit rules for AI agents
- When adding/changing ECS keywords, update both `k_` and `r_` methods if behaviour touches parsing or runtime state.
- Avoid renaming images or keys referenced from `img/` or `.ecs` scripts without updating all uses (ECS scripts reference names directly).
- Preserve Program/Handler contracts (do not change method signatures in `rbr_ui.py` Handler subclasses without confirming `easycoder` expectations).
- Keep UI changes isolated to `widgets.py` and logic/handler changes to `rbr_ui.py`. Small layout changes are fine; large refactors should be discussed.

### What to ask the maintainers before risky changes
- Are there backwards-compatibility expectations for `.ecs` script syntax?
- Is `easycoder` modified elsewhere in this repo or shared across multiple products (coordinate major handler changes)?

### Quick checklist — adding a new ECS keyword
Follow this compact checklist when adding a new language keyword/handler. It's based on patterns used in `rbr_ui.py` and the `easycoder/` core.

- Implement both methods on the Handler subclass: `k_<name>(self, command)` (compile/parse) and `r_<name>(self, command)` (runtime). The engine expects these names and signatures.
- In `k_<name>`:
  - Parse tokens with `nextToken()`, `nextIs()`, `nextValue()` and `getSymbolRecord()`.
  - Populate fields on `command` (e.g. `command['target'] = ...`) and call `self.add(command)` when ready.
  - Return True when the construct was recognised and added, otherwise False.
- In `r_<name>`:
  - Use `self.getVariable(name)` / `self.getRuntimeValue(value)` / `self.putSymbolValue()` to access and modify runtime values.
  - Return `self.nextPC()` to continue, `0`/`None` for blocking, or `-1` for exit semantics as appropriate.
- Value & condition hooks: if your keyword introduces new value or condition forms, implement `compileValue`, `compileCondition`, and corresponding `v_...` / `c_...` handlers on the same Handler.
- Tests: add a minimal `.ecs` example in `examples/` exercising your keyword, and a unit test in `tests/` that runs it via `Program(path).start()` (see `examples/run_example.py` and `tests/test_example.py`). Capture stdout when the handler prints to assert behaviour.
- Style: keywords are lower-case; variables use an initial capital letter (e.g. `variable X`).
- Safety: avoid changing Handler method signatures or core `Program` properties; if core APIs must change, update all callers and run full test/harness.

If anything here is unclear or you want me to include more examples (e.g. a checklist for adding a new ECS keyword or a concrete unit-test skeleton), tell me what you'd like and I will iterate.

### Example: run a tiny ECS script
We added `examples/example.ecs` (simple core-only script) and a harness `examples/run_example.py` that ensures the local `easycoder` package is used. From `Controller/ui` run:

```bash
python3 examples/run_example.py
```

This demonstrates a minimal, non-GUI execution path using the `core` domain (`variable`, `put`, `print`, `exit`).
