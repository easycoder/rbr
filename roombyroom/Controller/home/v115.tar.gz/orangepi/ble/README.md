# Mijia files #

The primary thermometer used in RBR is the Xiaomi Mijia, reflashed to put all its information into the BLE advert. Some of the fils here are for testing.
