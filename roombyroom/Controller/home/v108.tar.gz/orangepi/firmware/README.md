# Firmware
This section contains the source code for the XR relay, an ESP8266-powered 240V relay suited to controlling radiator valves (TRV actuators).

[The XR Relay](XR/doc/README.md)
