#!/bin/sh

# This is used on the development machine to update the distribution.

tar zcf ../../../Server/rbrheating.com/home/dist.tgz *
cp setup ../../../Server/rbrheating.com/home
cp version ../../../Server/rbrheating.com/home
